import os
import pandas as pd
from deep_translator import GoogleTranslator
from tqdm import tqdm
import time

# --- Lógica de Traducción ---

def translate_text(text_to_translate, target_language, retries=3, delay=2):
    """
    Traduce el texto usando el motor de Google Translate a través de deep-translator.
    Incluye reintentos para manejar errores de red.
    """
    if not isinstance(text_to_translate, str) or not text_to_translate.strip():
        return ""  # Devuelve vacío si la celda no es un string o está vacía

    # El formato del idioma en deep-translator puede ser 'pt' en lugar de 'pt-BR'
    # Simplificamos el código de idioma al código principal (ej. 'pt-BR' -> 'pt')
    simple_target_lang = target_language.split('-')[0]

    for attempt in range(retries):
        try:
            # Creamos el objeto de traducción y traducimos
            translated_text = GoogleTranslator(source='auto', target=simple_target_lang).translate(text_to_translate)
            # Pequeña pausa para no sobrecargar el servicio
            time.sleep(0.3)
            return translated_text
        except Exception as e:
            tqdm.write(f"\nError en intento {attempt + 1} para '{text_to_translate}': {e}")
            if attempt < retries - 1:
                tqdm.write(f"Reintentando en {delay * (2 ** attempt)} segundos...")
                time.sleep(delay * (2 ** attempt))
            else:
                tqdm.write(f"Fallaron todos los intentos para traducir '{text_to_translate}'.")
                return f"ERROR: {e}"
    return "ERROR_TRADUCCION_INESPERADO"

# --- Flujo Principal ---

def main():
    """
    Función principal que orquesta el proceso interactivo de traducción.
    """
    print("--- Asistente de Traducción de Excel (con Deep-Translator) ---")

    # --- Recopilación de datos del usuario ---

    # Usamos rutas relativas para simplificar
    default_input_file = 'traducciones.xls.xlsx'
    input_file = input(f"1. Introduce la ruta de tu archivo Excel (o presiona Enter para usar '{default_input_file}'): ").strip()
    if not input_file:
        input_file = default_input_file

    if not os.path.exists(input_file):
        print(f"Error: El archivo '{input_file}' no se encontró en la carpeta del proyecto.")
        return

    df_source = pd.read_excel(input_file)
    print("\nColumnas disponibles:", ", ".join(df_source.columns))

    while True:
        source_col = input("2. ¿Qué columna quieres traducir? (ej. 'en'): ").strip()
        if source_col in df_source.columns:
            break
        print("Error: Esa columna no existe en el archivo.")

    target_langs_str = input("3. Introduce los idiomas de destino separados por comas (ej. pt-BR, fr, de): ").strip()
    target_langs = [lang.strip() for lang in target_langs_str.split(',')]

    default_output_file = 'Traducido.xls.xlsx'
    output_file = input(f"4. ¿Cómo quieres llamar al archivo de salida? (o presiona Enter para '{default_output_file}'): ").strip()
    if not output_file:
        output_file = default_output_file
    if not output_file.endswith('.xlsx'):
        output_file += '.xlsx'

    # --- Preparación del DataFrame y Reanudación ---

    if os.path.exists(output_file):
        print(f"\nSe encontró un archivo de salida existente: '{output_file}'.")
        print("Se reanudará el proceso, actualizando solo las celdas vacías o con errores.")
        df_output = pd.read_excel(output_file)
    else:
        print("\nCreando nuevo archivo de salida...")
        df_output = df_source.copy()

    # Añadir columnas de destino si no existen
    for lang in target_langs:
        col_name = f"{source_col}_{lang}"
        if col_name not in df_output.columns:
            df_output[col_name] = ""

    # --- Proceso de Traducción ---

    # Determinar las filas que necesitan traducción
    rows_to_process = []
    for index, row in df_output.iterrows():
        is_incomplete = False
        for lang in target_langs:
            col_name = f"{source_col}_{lang}"
            # Si la celda está vacía, es nula o contiene un error previo, necesita traducción
            if pd.isna(row[col_name]) or not str(row[col_name]).strip() or str(row[col_name]).startswith("ERROR"):
                is_incomplete = True
                break
        if is_incomplete:
            rows_to_process.append(index)

    if not rows_to_process:
        print("\n¡El archivo ya está completamente traducido! No hay nada que hacer.")
        return

    print(f"\nTraduciendo {len(rows_to_process)} filas...")
    with tqdm(total=len(rows_to_process), desc="Traduciendo filas") as pbar:
        for index in rows_to_process:
            text_to_translate = str(df_source.at[index, source_col])

            for lang in target_langs:
                col_name = f"{source_col}_{lang}"
                current_val = str(df_output.at[index, col_name])

                if pd.isna(df_output.at[index, col_name]) or not current_val.strip() or current_val.startswith("ERROR"):
                    translated_text = translate_text(text_to_translate, lang)
                    df_output.at[index, col_name] = translated_text

            # Guardado progresivo después de cada fila
            df_output.to_excel(output_file, index=False)
            pbar.update(1)

    print(f"\n¡Traducción completada! El archivo se ha guardado en: {output_file}")


if __name__ == "__main__":
    main()